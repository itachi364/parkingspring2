package com.example.prueba_michael.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.prueba_michael.InterfaceService.IPersonaS;
import com.example.prueba_michael.interfaces.IPersona;
import com.example.prueba_michael.modelo.Persona;


@Service
public class PersonaSer implements IPersonaS {

	@Autowired
	private IPersona data;
	@Override
	public List<Persona> listar() {
		return (List<Persona>)data.findAll();
	}

	@Override
	public Optional<Persona> listarId(int id) {
		// TODO Auto-generated method stub
		return data.findById(id);
	}

	@Override
	public int save(Persona p) {
		// TODO Auto-generated method stub
		int res =0;
		Persona persona = data.save(p);
		if (!persona.equals(null)) {
			res=1;
		}
		return 0;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		data.deleteById(id);
		
	}
	
	

}
