package com.example.prueba_michael;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prueba_MVanegas {

	public static void main(String[] args) {
		SpringApplication.run(Prueba_MVanegas.class, args);
	}

}
