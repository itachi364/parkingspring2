package com.example.prueba_michael.InterfaceService;

import java.util.List;
import java.util.Optional;

import com.example.prueba_michael.modelo.Persona;

public interface IPersonaS {
	public List<Persona>listar();
	public Optional<Persona>listarId(int id);
	public int save(Persona p);
	public void delete(int id);

}
