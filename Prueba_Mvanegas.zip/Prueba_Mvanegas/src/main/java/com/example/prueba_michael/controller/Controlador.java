package com.example.prueba_michael.controller;

import java.util.List;
import java.util.Optional;


import javax.validation.Valid;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.prueba_michael.InterfaceService.IPersonaS;
import com.example.prueba_michael.modelo.Persona;


@Controller
@RequestMapping
public class Controlador {
	@Autowired
	private IPersonaS service;
	
	@GetMapping("/listar")
		public String listar(Model model) {
		List<Persona>personas=service.listar();
		model.addAttribute("personas", personas);
		return "index";
		
	}
	
	@GetMapping("/new")
	public String agregar(Model model) {
		model.addAttribute("persona", new Persona()); 
		return "form";
	}
	
	@PostMapping("/save")
	public String save (@Valid Persona p, Model model) {
		service.save(p);
		return "redirect:/listar";
		
	}
	@GetMapping("/update/{id}")
	public String update(@PathVariable int id, Model model) {
		Optional<Persona>persona=service.listarId(id);
		model.addAttribute("persona", persona);
		return "form";
	}

	@GetMapping("/delete/{id}")
	public String delete(Model model, @PathVariable int id) {
		service.delete(id);
		return "redirect:/listar";
	}
}
